// config.js - Configuração da API Mock
const API_CONFIG = {
  baseUrl: 'http://localhost:3001',
  
  refreshIntervals: {
    sensors: 10000,
    dashboard: 15000,
    alarms: 5000,
  },
  
  endpoints: {
    sensorZones: '/api/sensors/zones',
    sensorTemperature: (zone) => `/api/sensors/${zone}/temperature`,
    sensorHumidity: (zone) => `/api/sensors/${zone}/humidity`,
    scadaAlarms: '/api/scada/alarms',
    streamAlarms: '/api/stream/scada/alarms',
  }
};
