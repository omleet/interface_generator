/**
 * app.js - Versão Dinâmica
 * Dashboard que consome dados da API Mock (REST e SSE)
 */

$(function() {
  // --- Configuração da API (Integrada) ---
  const API_CONFIG = {
    baseUrl: 'http://localhost:3001',
    endpoints: {
      zones: '/api/sensors/zones',
      temp: (z) => `/api/sensors/${z}/temperature`,
      hum: (z) => `/api/sensors/${z}/humidity`,
      alarms: '/api/scada/alarms',
      streamAlarms: '/api/stream/scada/alarms'
    },
    intervals: { dashboard: 15000 }
  };

  // --- Estado Global ---
  let charts = {};
  let autoRefreshId = null;
  let sseSource = null;

  // --- Inicialização ---
  function init() {
    setupEventListeners();
    loadAllData();
    connectSSE();
    if ($('#autoRefreshSwitch').is(':checked')) startPolling();
  }

  // --- Funções de API ---
  async function apiFetch(endpoint) {
    try {
      const response = await fetch(`${API_CONFIG.baseUrl}${endpoint}`);
      if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);
      return await response.json();
    } catch (err) {
      console.error(`Erro ao buscar ${endpoint}:`, err);
      return null;
    }
  }

  function connectSSE() {
    if (sseSource) sseSource.close();
    sseSource = new EventSource(`${API_CONFIG.baseUrl}${API_CONFIG.endpoints.streamAlarms}`);
    
    sseSource.onmessage = (e) => {
      const data = JSON.parse(e.data);
      updateAlarms(Array.isArray(data) ? data : [data]);
    };

    sseSource.onerror = () => {
      console.warn('Erro no SSE, tentando reconectar...');
      setTimeout(connectSSE, 5000);
    };
  }

  // --- Carregamento de Dados ---
  async function loadAllData() {
    const zones = await apiFetch(API_CONFIG.endpoints.zones);
    if (!zones) return;

    updateZoneTable(zones);
    updateZoneFilter(zones);

    const tempDatasets = [];
    const humDatasets = [];
    const currentReadings = { labels: [], temp: [], hum: [] };

    for (const zone of zones) {
      const tData = await apiFetch(API_CONFIG.endpoints.temp(zone.zone));
      const hData = await apiFetch(API_CONFIG.endpoints.hum(zone.zone));

      if (tData && tData.history) {
        tempDatasets.push({
          label: zone.zone,
          data: tData.history.map(h => h.value),
          borderColor: getZoneColor(zone.zone),
          backgroundColor: getZoneColor(zone.zone) + '20',
          tension: 0.3, pointRadius: 2
        });
        currentReadings.temp.push(tData.value);
      }

      if (hData && hData.history) {
        humDatasets.push({
          label: zone.zone,
          data: hData.history.map(h => h.value),
          borderColor: getZoneColor(zone.zone),
          backgroundColor: getZoneColor(zone.zone) + '20',
          tension: 0.3, pointRadius: 2
        });
        currentReadings.hum.push(hData.value);
      }
      currentReadings.labels.push(zone.zone);
    }

    renderCharts(tempDatasets, humDatasets, currentReadings);
    
    const alarms = await apiFetch(API_CONFIG.endpoints.alarms);
    if (alarms) updateAlarms(alarms);
  }

  // --- Renderização de UI ---
  function renderCharts(tempData, humData, current) {
    const labels = Array.from({length: 24}, (_, i) => `${String(i).padStart(2,'0')}:00`);

    // Gráfico de Temperatura
    if (charts.temp) charts.temp.destroy();
    charts.temp = new Chart(document.getElementById('temperatureChart'), {
      type: 'line',
      data: { labels, datasets: tempData },
      options: { responsive: true, maintainAspectRatio: false, scales: { y: { min: 15, max: 45 } } }
    });

    // Gráfico de Humidade
    if (charts.hum) charts.hum.destroy();
    charts.hum = new Chart(document.getElementById('humidityChart'), {
      type: 'line',
      data: { labels, datasets: humData },
      options: { responsive: true, maintainAspectRatio: false, scales: { y: { min: 20, max: 100 } } }
    });

    // Gráfico de Barras Atual
    if (charts.bar) charts.bar.destroy();
    charts.bar = new Chart(document.getElementById('currentReadingsChart'), {
      type: 'bar',
      data: {
        labels: current.labels,
        datasets: [
          { label: 'Temp (°C)', data: current.temp, backgroundColor: '#28a745' },
          { label: 'Hum (%)', data: current.hum, backgroundColor: '#17a2b8' }
        ]
      },
      options: { responsive: true, maintainAspectRatio: false }
    });
  }

  function updateZoneTable(zones) {
    const tbody = $('#zoneTable tbody');
    tbody.empty();
    zones.forEach(z => {
      tbody.append(`
        <tr data-zone="${z.zone}">
          <td><i class="fas fa-layer-group mr-2"></i>${z.zone}</td>
          <td>${zones.length}</td>
          <td>${z.temperature.toFixed(1)}°C</td>
          <td>${z.humidity.toFixed(1)}%</td>
          <td><span class="badge badge-${z.status === 'ok' ? 'success' : 'warning'}">${z.status.toUpperCase()}</span></td>
          <td>Agora</td>
          <td><button class="btn btn-sm btn-info"><i class="fas fa-eye"></i></button></td>
        </tr>
      `);
    });
  }

  function updateAlarms(alarms) {
    $('.navbar-badge').text(alarms.length);
    const list = $('.dropdown-menu-lg');
    list.find('.dropdown-item').remove();
    alarms.slice(0, 5).forEach(a => {
      list.append(`<a href="#" class="dropdown-item"><i class="fas fa-exclamation-triangle text-danger mr-2"></i> ${a.message}</a>`);
    });

    // Gráfico de Alarmes
    const counts = { critical: 0, warning: 0, info: 0 };
    alarms.forEach(a => counts[a.severity]++);
    if (charts.pie) charts.pie.destroy();
    charts.pie = new Chart(document.getElementById('alertDistributionChart'), {
      type: 'doughnut',
      data: {
        labels: ['Crítico', 'Aviso', 'Info'],
        datasets: [{ data: [counts.critical, counts.warning, counts.info], backgroundColor: ['#dc3545', '#ffc107', '#17a2b8'] }]
      },
      options: { responsive: true, maintainAspectRatio: false, cutout: '70%' }
    });
  }

  // --- Auxiliares ---
  function getZoneColor(zone) {
    const colors = ['#17a2b8', '#ffc107', '#28a745', '#6c757d', '#20c997', '#fd7e14'];
    const idx = zone.charCodeAt(zone.length - 1) % colors.length;
    return colors[idx];
  }

  function updateZoneFilter(zones) {
    const select = $('#zoneFilter');
    if (select.children().length > 1) return;
    zones.forEach(z => select.append(`<option value="${z.zone}">${z.zone}</option>`));
  }

  function startPolling() {
    if (autoRefreshId) clearInterval(autoRefreshId);
    autoRefreshId = setInterval(loadAllData, API_CONFIG.intervals.dashboard);
  }

  function setupEventListeners() {
    $('#refreshBtn').on('click', function() {
      $(this).addClass('spinning');
      loadAllData().finally(() => $(this).removeClass('spinning'));
    });

    $('#autoRefreshSwitch').on('change', function() {
      if ($(this).is(':checked')) startPolling();
      else clearInterval(autoRefreshId);
    });

    $('#tableSearch').on('keyup', function() {
      const val = $(this).val().toLowerCase();
      $('#zoneTable tbody tr').filter(function() {
        $(this).toggle($(this).text().toLowerCase().indexOf(val) > -1);
      });
    });
  }

  init();
});
