import streamlit as st
import pandas as pd
import plotly.express as px
import numpy as np
import plotly.graph_objects as go
import requests
import time
from datetime import datetime

st.set_page_config(page_title='Environment Monitor', page_icon='🌡️', layout='wide')

API_BASE_URL = "http://localhost:3001/api"

# Funções de API sem cache para garantir dados frescos
def fetch_zones_data():
    try:
        # Adicionar um timestamp à query para evitar cache do lado do cliente/proxy se necessário
        response = requests.get(f"{API_BASE_URL}/sensors/zones?t={time.time()}", timeout=2)
        if response.status_code == 200:
            return response.json()
    except Exception:
        pass
    return []

def fetch_zone_history(zone, metric):
    try:
        response = requests.get(f"{API_BASE_URL}/sensors/{zone}/{metric}?t={time.time()}", timeout=2)
        if response.status_code == 200:
            return response.json().get('history', [])
    except Exception:
        pass
    return []

# Inicialização do estado da sessão
if 'auto_refresh' not in st.session_state:
    st.session_state.auto_refresh = False

if 'history' not in st.session_state:
    st.session_state.history = pd.DataFrame(columns=['timestamp', 'zone', 'temperature', 'humidity'])
    # Carga inicial do histórico
    zones_init = fetch_zones_data()
    history_list = []
    for z in (zones_init[:3] if zones_init else []):
        t_hist = fetch_zone_history(z['zone'], 'temperature')
        h_hist = fetch_zone_history(z['zone'], 'humidity')
        for t, h in zip(t_hist, h_hist):
            history_list.append({
                'timestamp': pd.to_datetime(t['ts'], utc=True),
                'zone': z['zone'],
                'temperature': t['value'],
                'humidity': h['value']
            })
    if history_list:
        st.session_state.history = pd.DataFrame(history_list)

if 'current_readings' not in st.session_state:
    st.session_state.current_readings = {}

# Sidebar
with st.sidebar:
    st.header('Monitor Settings')
    
    # Obter zonas (sempre atualizado para o multiselect)
    zones_payload = fetch_zones_data()
    ZONES_LIST = [z['zone'] for z in zones_payload] if zones_payload else ['Zone-A', 'Zone-B', 'Zone-C']
    
    selected_zones = st.multiselect('Select Zones', ZONES_LIST, default=ZONES_LIST[:3])
    time_range = st.slider('Time Range (hours)', 1, 24, 24)
    temp_threshold = st.number_input('Temperature Threshold (°C)', value=30, step=1)
    humidity_threshold = st.number_input('Humidity Threshold (%)', value=70, step=1)
    refresh_interval = st.slider('Refresh Interval (seconds)', 1, 30, 5)
    
    if st.button('▶️ Start' if not st.session_state.auto_refresh else '⏹️ Stop'):
        st.session_state.auto_refresh = not st.session_state.auto_refresh
        st.rerun()

# Main UI
st.title('🌡️ Environment Monitor')
st.caption(f'Connected to Mock API | Last sync: {datetime.now().strftime("%H:%M:%S")}')

# Lógica de Atualização de Dados
# Se estiver em auto-refresh, esperamos o tempo e fazemos rerun.
# Os dados são SEMPRE lidos no início de cada execução do script.

# 1. Ler dados atuais da API
current_api_data = fetch_zones_data()
if current_api_data:
    now = pd.Timestamp.now(tz='UTC')
    for z in current_api_data:
        z_name = z['zone']
        # Atualizar leituras atuais para todas as zonas conhecidas
        st.session_state.current_readings[z_name] = {
            'temperature': z['temperature'],
            'humidity': z['humidity']
        }
        
        # Se estiver em modo auto-refresh e a zona estiver selecionada, adicionamos ao histórico
        if st.session_state.auto_refresh and z_name in selected_zones:
            new_row = pd.DataFrame([{
                'timestamp': now,
                'zone': z_name,
                'temperature': z['temperature'],
                'humidity': z['humidity']
            }])
            st.session_state.history = pd.concat([st.session_state.history, new_row], ignore_index=True)

# Preparar DataFrames para visualização
df_history = st.session_state.history.copy()
if not df_history.empty:
    df_history['timestamp'] = pd.to_datetime(df_history['timestamp'], utc=True)
    cutoff = pd.Timestamp.now(tz='UTC') - pd.Timedelta(hours=time_range)
    df_history = df_history[(df_history['zone'].isin(selected_zones)) & (df_history['timestamp'] >= cutoff)]

current_list = []
for zone in selected_zones:
    if zone in st.session_state.current_readings:
        readings = st.session_state.current_readings[zone]
        status = 'Normal'
        if readings['temperature'] > temp_threshold or readings['humidity'] > humidity_threshold:
            status = 'Alert'
        elif readings['temperature'] > temp_threshold - 3 or readings['humidity'] > humidity_threshold - 5:
            status = 'Warning'
            
        current_list.append({
            'Zone': zone,
            'Temperature (°C)': round(readings['temperature'], 1),
            'Humidity (%)': round(readings['humidity'], 1),
            'Status': status
        })

current_df = pd.DataFrame(current_list)

# Metrics
if not current_df.empty:
    c1, c2, c3, c4 = st.columns(4)
    avg_t = current_df['Temperature (°C)'].mean()
    avg_h = current_df['Humidity (%)'].mean()
    alerts = len(current_df[current_df['Status'] == 'Alert'])
    
    c1.metric('🌡️ Avg Temp', f'{avg_t:.1f}°C')
    c2.metric('💧 Avg Humidity', f'{avg_h:.1f}%')
    c3.metric('📍 Zones', len(selected_zones))
    c4.metric('⚠️ Alerts', alerts, delta_color='inverse' if alerts > 0 else 'normal')

# Tabs
tab1, tab2 = st.tabs(['📈 Charts', '📋 Data'])

with tab1:
    col1, col2 = st.columns(2)
    with col1:
        if not df_history.empty:
            fig_t = px.line(df_history, x='timestamp', y='temperature', color='zone', title='Temperature Trends')
            st.plotly_chart(fig_t, use_container_width=True)
    with col2:
        if not df_history.empty:
            fig_h = px.line(df_history, x='timestamp', y='humidity', color='zone', title='Humidity Trends')
            st.plotly_chart(fig_h, use_container_width=True)
            
    col3, col4 = st.columns(2)
    with col3:
        if not current_df.empty:
            fig_b_t = px.bar(current_df, x='Zone', y='Temperature (°C)', color='Temperature (°C)', color_continuous_scale='RdYlBu_r')
            st.plotly_chart(fig_b_t, use_container_width=True)
    with col4:
        if not current_df.empty:
            fig_b_h = px.bar(current_df, x='Zone', y='Humidity (%)', color='Humidity (%)', color_continuous_scale='Blues')
            st.plotly_chart(fig_b_h, use_container_width=True)

with tab2:
    if not current_df.empty:
        st.dataframe(current_df, use_container_width=True, hide_index=True)

# Lógica de espera para o próximo ciclo
if st.session_state.auto_refresh:
    time.sleep(refresh_interval)
    st.rerun()
